package org.wikipedia.test;

import android.app.Activity;

/**
 * Dummy activity that does nothing and is happy about it.
 *
 * Used to do things on the UI thread in unit tests.
 */
public class TestDummyActivity extends Activity {
}